/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CareInstructions {
  watering: string; // آب‌رسانی
  light: string;    // جایگاه خورشید (نور)
  soil: string;     // خاک و آوند (خوراک)
  climate: string;  // سازگاری با اقلیم (دما)
}

export interface PlantIdentificationResult {
  commonName: string;       // نام فارسی رایج
  scientificName: string;   // نام علمی
  ancientName: string;      // نام باستانی / اوستایی گیاه
  confidence: number;       // درصد اطمینان
  mythology: string;        // پیشینه اساطیری و تاریخی در ایران باستان
  summary: string;          // خلاصه وضعیت و عیب‌یابی گیاه
  careInstructions: CareInstructions;
  healingProperties: string; // خواص درمانی و سنتی هخامنشی
  royalAdvice: string;      // اندرز شاهانه (منسوب به منشور کوروش یا داریوش بزرگ)
}

export interface PlantPreset {
  id: string;
  name: string;
  scientificName: string;
  ancientName: string;
  imageUrl: string;
  result: PlantIdentificationResult;
}
