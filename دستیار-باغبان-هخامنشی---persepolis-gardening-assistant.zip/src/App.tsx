/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Sparkles, 
  Camera, 
  UploadCloud, 
  Sprout, 
  Droplets, 
  Sun, 
  Globe, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowLeft, 
  ArrowRight,
  BookOpen,
  HeartPulse,
  Award,
  Scroll,
  RotateCcw,
  RefreshCw,
  VideoOff
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { PLANT_PRESETS } from "./data";
import { PlantIdentificationResult } from "./types";

const BANNER_IMAGE = "/src/assets/images/persepolis_garden_1780121165820.png";
const FALLBACK_BANNER = "https://images.unsplash.com/photo-1589156280159-27698a70f29e?auto=format&fit=crop&q=80&w=1200";

// Gorgeous rotating royal botanist announcements during analysis
const LOADING_STEPS = [
  "در حال بازگشایی بایگانی سلطنتی پاسارگاد و طومارهای کهن...",
  "رایزنی با پزشکان دربار و داروشناسان هخامنشی پیرامون آوندهای گیاه...",
  "انطباق نگاره با نقش‌برجسته‌های نیلوفر آبی و نقوش گل‌های دوازده‌پرِ تخت جمشید...",
  "بررسی رطوبت بستر اسپندارمد (زمین پاک) و نیاز گیاه به مهر تابان...",
  "تدوین کارنامه تندرستی و فرامین مراقبتی باغبان سلطنتی..."
];

export default function App() {
  const [selectedPlant, setSelectedPlant] = useState<PlantIdentificationResult | null>(PLANT_PRESETS[0].result);
  const [selectedImage, setSelectedImage] = useState<string | null>(PLANT_PRESETS[0].imageUrl);
  const [activePresetId, setActivePresetId] = useState<string | null>("lotus");
  
  // App States
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingStepIndex, setLoadingStepIndex] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [history, setHistory] = useState<Array<{
    name: string;
    scientificName: string;
    date: string;
    image: string;
    result: PlantIdentificationResult;
  }>>([]);

  // Camera settings
  const [showCamera, setShowCamera] = useState<boolean>(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load history from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("persepolis_gardening_history");
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading history", e);
      }
    }
  }, []);

  // Interval for rotating load text
  useEffect(() => {
    let interval: any;
    if (loading) {
      interval = setInterval(() => {
        setLoadingStepIndex((prev) => (prev + 1) % LOADING_STEPS.length);
      }, 3000);
    } else {
      setLoadingStepIndex(0);
    }
    return () => clearInterval(interval);
  }, [loading]);

  // Handle Drag & Drop
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processAndUploadFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      setError("تنها پرونده‌های عکس (تنگ‌نگاره) پشتیبانی می‌شوند.");
      return;
    }
    setError(null);
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64 = reader.result as string;
      setSelectedImage(base64);
      setActivePresetId(null);
      identifyPlant(base64, file.type);
    };
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processAndUploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processAndUploadFile(e.target.files[0]);
    }
  };

  // Launch Camera Stream
  const startCamera = async () => {
    setError(null);
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error("Camera Access Error:", err);
      setError("امکان دسترسی به دوربین فراهم نشد. لطفاً مجوز دسترسی را بررسی نموده یا فایلی را بارگذاری کنید.");
      setShowCamera(false);
    }
  };

  // Capture Camera Frame
  const capturePhoto = () => {
    if (videoRef.current && cameraStream) {
      const canvas = document.createElement("canvas");
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const base64 = canvas.toDataURL("image/jpeg");
        setSelectedImage(base64);
        setActivePresetId(null);
        closeCamera();
        identifyPlant(base64, "image/jpeg");
      }
    }
  };

  // Stop Camera Stream
  const closeCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setShowCamera(false);
  };

  // Post image base64 to server API
  const identifyPlant = async (base64Data: string, mimeType: string) => {
    setLoading(true);
    setError(null);
    setSelectedPlant(null);

    // Grab raw base64 data without prefix (data:image/jpeg;base64,...)
    const cleanBase64 = base64Data.split(",")[1];

    try {
      const response = await fetch("/api/identify-plant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: cleanBase64,
          mimeType: mimeType
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "رویداد پیش‌بینی نشده در برقراری پیوند رخ داد.");
      }

      setSelectedPlant(data);

      // Save to history list
      const historyItem = {
        name: data.commonName,
        scientificName: data.scientificName,
        date: new Date().toLocaleDateString("fa-IR"),
        image: base64Data,
        result: data
      };

      const updatedHistory = [historyItem, ...history.slice(0, 19)];
      setHistory(updatedHistory);
      localStorage.setItem("persepolis_gardening_history", JSON.stringify(updatedHistory));

    } catch (err: any) {
      console.error(err);
      setError(err.message || "برقراری ارتباط با پایتخت شاهنشاهی با اختلال روبرو شد. لطفاً اینترنت خود را بازنگری فرمایید.");
    } finally {
      setLoading(false);
    }
  };

  // Load a preset
  const handleSelectPreset = (preset: typeof PLANT_PRESETS[0]) => {
    setError(null);
    setSelectedImage(preset.imageUrl);
    setSelectedPlant(preset.result);
    setActivePresetId(preset.id);
  };

  // Clear Specific History Box
  const handleRemoveHistory = (index: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = history.filter((_, i) => i !== index);
    setHistory(updated);
    localStorage.setItem("persepolis_gardening_history", JSON.stringify(updated));
  };

  // Clear App Selections back to default
  const handleReset = () => {
    handleSelectPreset(PLANT_PRESETS[0]);
  };

  return (
    <div id="persepolis-gardening-app" className="min-h-screen bg-[#fbf9f4] bg-persepolis-motif pb-16 transition-colors duration-300">
      
      {/* Dynamic Header with Parallax Illustration */}
      <header className="relative w-full overflow-hidden bg-[#0c1a30] text-[#f4efe6] shadow-2xl">
        <div className="absolute inset-0 z-0 bg-gradient-to-t from-[#0a1526] via-transparent to-black/60" />
        
        {/* Persepolis Generated Background banner */}
        <div className="absolute inset-0 z-0 opacity-40">
          <img 
            src={BANNER_IMAGE} 
            alt="باغ هخامنشی" 
            className="h-full w-full object-cover object-center scale-105 transition-transform duration-700 hover:scale-100"
            referrerPolicy="no-referrer"
            onError={(e) => {
              e.currentTarget.src = FALLBACK_BANNER;
            }}
          />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-4 py-12 md:py-16 text-center select-none flex flex-col items-center">
          
          {/* Ancient Faravahar / Sun Styled Medallion */}
          <motion.div 
            initial={{ rotate: -15, scale: 0.8, opacity: 0 }}
            animate={{ rotate: 0, scale: 1, opacity: 1 }}
            transition={{ duration: 1 }}
            className="mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-[#c5a880]/60 bg-[#162a45]/80 text-[#c5a880]"
          >
            <Sun className="h-8 w-8 animate-spin-slow text-[#c5a880]" />
          </motion.div>

          <h1 className="font-serif text-3xl md:text-5xl font-extrabold tracking-wide mb-3 text-[#fcfaf6] drop-shadow-md">
            دستیارِ باغبانِ دیوانِ هخامنشی
          </h1>
          
          <p className="max-w-2xl font-sans text-sm md:text-base text-[#c5a880] leading-relaxed tracking-wide font-normal">
            به پردیس شاهانه پاسارگاد خوش آمدید. نگاره‌ای از گیاه خود را بارگذاری کنید تا باغ‌بانان دربار، پیشینهِ اساطیری، خواص شفابخش و چهار ستون نگهداری آن را فاش گردانند.
          </p>

          <div className="mt-4 flex flex-wrap gap-2 justify-center">
            <span className="px-3 py-1 text-xs rounded-full bg-[#c5a880]/20 border border-[#c5a880]/30 text-[#fcfaf6]">🏛️ تم تخت جمشید</span>
            <span className="px-3 py-1 text-xs rounded-full bg-[#c5a880]/20 border border-[#c5a880]/30 text-[#fcfaf6]">🌱 باغ‌های پردیس</span>
            <span className="px-3 py-1 text-xs rounded-full bg-[#c5a880]/20 border border-[#c5a880]/30 text-[#fcfaf6]">🗳️ دکمه‌های کاملاً فارسی</span>
          </div>
        </div>

        {/* Traditional column bottom shape border */}
        <div className="absolute bottom-0 left-0 right-0 h-4 bg-[#fbf9f4] rounded-t-2xl z-20" />
      </header>

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-4 mt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Side: Upload Gateway, Camera Control, and Presets Selection */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Action Card: Capture or Upload */}
            <div className="bg-white border border-[#c5a880]/30 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="p-4 bg-[#f8f5ee] border-b border-[#c5a880]/20 flex items-center justify-between">
                <h3 className="font-sans font-bold text-base text-[#5c4a37] flex items-center gap-2">
                  <Camera className="h-5 w-5 text-[#c5a880]" />
                  درگاه ورودی باغ‌داری (بارگذاری)
                </h3>
              </div>

              <div className="p-5 space-y-5">
                
                {/* Drag and Drop Zone */}
                <div 
                  onDragEnter={handleDrag}
                  onDragOver={handleDrag}
                  onDragLeave={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                    dragActive 
                      ? "border-[#c5a880] bg-[#f4efe6]/50" 
                      : "border-stone-300 hover:border-[#c5a880] bg-[#fdfdfc] hover:bg-[#faf8f5]"
                  }`}
                >
                  <input 
                    ref={fileInputRef}
                    id="plant-photo-input"
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleFileChange}
                  />
                  <div className="flex flex-col items-center justify-center space-y-3">
                    <div className="p-3 rounded-full bg-[#f4efe6] text-[#c5a880]">
                      <UploadCloud className="h-8 w-8" />
                    </div>
                    <div>
                      <p className="font-sans font-medium text-sm text-[#5c4a37]">
                        کِشیدن و رَها کردن نگاره، یا دکمه زیر
                      </p>
                      <p className="font-sans text-xs text-stone-500 mt-1">
                        فرمت‌های مجاز: PNG, JPG, JPEG (تا حجم ۱۰ مگابایت)
                      </p>
                    </div>
                  </div>
                </div>

                {/* Persian Buttons Layout: Select File & Take Photo */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    id="choose-file-btn"
                    onClick={() => fileInputRef.current?.click()}
                    className="py-2.5 px-4 rounded-lg bg-[#c5a880] hover:bg-[#b0936b] active:bg-[#9a7e58] text-[#fcfaf6] font-sans font-bold text-xs transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <UploadCloud className="h-4 w-4" />
                    انتخاب نگاره گیاه
                  </button>

                  <button
                    id="trigger-camera-btn"
                    onClick={startCamera}
                    className="py-2.5 px-4 rounded-lg bg-[#0c1a30] hover:bg-[#152e50] active:bg-[#07111f] text-[#fcfaf6] font-sans font-bold text-xs transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Camera className="h-4 w-4 text-[#c5a880]" />
                    گرفتن فرتور با دوربین
                  </button>
                </div>
              </div>
            </div>

            {/* Ancient Plant Presets Gallery (کلکسیون گیاهان کهن) */}
            <div className="bg-white border border-[#c5a880]/30 rounded-xl overflow-hidden shadow-sm">
              <div className="p-4 bg-[#f8f5ee] border-b border-[#c5a880]/20">
                <h3 className="font-sans font-bold text-base text-[#5c4a37] flex items-center gap-2">
                  <Sprout className="h-5 w-5 text-[#c5a880]" />
                  باغ تمثیلی پیش‌فرض هخامنشیان
                </h3>
                <p className="font-sans text-xs text-stone-600 mt-1">
                  برای آزمایش فوری برنامه، یکی از نمونه‌های زیر را انتخاب فرمایید:
                </p>
              </div>

              <div className="p-4 space-y-3">
                {PLANT_PRESETS.map((preset) => {
                  const isActive = activePresetId === preset.id;
                  return (
                    <button
                      key={preset.id}
                      onClick={() => handleSelectPreset(preset)}
                      className={`w-full text-right p-2.5 rounded-lg border transition-all flex items-center justify-between cursor-pointer ${
                        isActive
                          ? "border-[#c5a880] bg-[#f4efe6]/40 shadow-sm"
                          : "border-stone-200 bg-[#fdfdfc] hover:bg-[#faf9f6]"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <img 
                          src={preset.imageUrl} 
                          alt={preset.name} 
                          className="w-12 h-12 rounded-md object-cover border border-[#c5a880]/30"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <p className="font-sans font-bold text-xs text-[#44382c]">
                            {preset.name}
                          </p>
                          <p className="font-sans text-[10px] text-stone-500 italic">
                            {preset.scientificName}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 pl-1">
                        <span className="text-[10px] font-sans text-[#c5a880] rounded bg-[#c5a880]/10 px-1.5 py-0.5">پیش برگزیده</span>
                        <ArrowLeft className="h-3 w-3 text-stone-400" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* History List of Gardeners */}
            {history.length > 0 && (
              <div className="bg-white border border-[#c5a880]/30 rounded-xl overflow-hidden shadow-sm">
                <div className="p-4 bg-[#f8f5ee] border-b border-[#c5a880]/20 flex items-center justify-between">
                  <h3 className="font-sans font-bold text-xs text-[#5c4a37] flex items-center gap-1.5">
                    <Scroll className="h-4 w-4 text-[#c5a880]" />
                    طومار پیشینه‌های باغبان شما ({history.length})
                  </h3>
                  <button
                    onClick={() => {
                      setHistory([]);
                      localStorage.removeItem("persepolis_gardening_history");
                    }}
                    className="p-1 rounded hover:bg-red-50 text-red-600 transition-colors cursor-pointer"
                    title="پاک کردن تاریخچه"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-stone-100">
                  {history.map((item, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setSelectedImage(item.image);
                        setSelectedPlant(item.result);
                        setActivePresetId(null);
                      }}
                      className="p-3 hover:bg-stone-50 cursor-pointer flex items-center justify-between gap-2 transition-all"
                    >
                      <div className="flex items-center gap-2">
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          className="w-10 h-10 rounded object-cover border border-stone-200"
                        />
                        <div>
                          <p className="font-sans font-bold text-xs text-[#44382c] line-clamp-1">
                            {item.name}
                          </p>
                          <p className="font-sans text-[9px] text-stone-500 line-clamp-1 italic">
                            {item.scientificName}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-stone-600">
                          {item.date}
                        </span>
                        <button
                          onClick={(e) => handleRemoveHistory(idx, e)}
                          className="p-1 text-stone-400 hover:text-red-500 rounded cursor-pointer"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Side: Deep Results Clay Tablet, Image Previews & Loading Gates */}
          <div className="lg:col-span-8">
            
            {/* Error Shield */}
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 rounded-xl border border-red-200 bg-red-50 text-red-800 flex items-start gap-3 shadow-sm"
              >
                <div className="p-1.5 rounded-full bg-red-100 text-red-700 mt-0.5">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h4 className="font-sans font-bold text-sm">پیام از دیوان محاسبات شاهنشاهی</h4>
                  <p className="font-sans text-xs mt-1 leading-relaxed">{error}</p>
                  {error.includes("API") && (
                    <div className="mt-2 text-xs bg-red-100/50 p-2 rounded text-red-900 leading-tight">
                      راهکار: یک کلید معتبر به نام <strong>GEMINI_API_KEY</strong> در منوی دکمه بالا سمت راست چت یا تنظیمات (Secrets) وارد نمایید تا هوش مصنوعی تخت جمشید درجا فعال شود.
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Beautiful Central Live Video / Image preview layout */}
            <div className="relative mb-6 rounded-xl overflow-hidden bg-[#fafafa] border border-[#c5a880]/30 shadow-sm max-h-[360px] flex items-center justify-center">
              
              {selectedImage ? (
                <div className="relative w-full h-[280px] md:h-[340px]">
                  <img
                    src={selectedImage}
                    alt="تصویر مورد تحلیل گیاه"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/20" />
                  
                  {/* Decorative corner carvings */}
                  <div className="absolute top-3 right-3 text-[#fcfaf6] font-sans text-xs bg-[#0c1a30]/80 backdrop-blur border border-[#c5a880]/50 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#c5a880] animate-pulse" />
                    {activePresetId ? "نمونه پیش‌فرض دالان سلطنتی" : "نگاره ارسالی باغبان جوان"}
                  </div>

                  {/* Reset action button */}
                  <button
                    onClick={handleReset}
                    className="absolute bottom-3 right-3 py-1.5 px-3 rounded bg-white/20 hover:bg-white/30 backdrop-blur text-white text-xs border border-white/20 flex items-center gap-2 transition-all cursor-pointer"
                  >
                    <RotateCcw className="h-3 w-3" />
                    بارنشانی باغ پردیس
                  </button>
                </div>
              ) : (
                <div className="h-[280px] md:h-[340px] flex flex-col items-center justify-center text-center space-y-4 p-6 text-stone-500">
                  <div className="p-4 rounded-full bg-stone-100 text-stone-400">
                    <Sprout className="h-12 w-12" />
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-sm text-[#44382c]">هیچ فرتور یا نمونه‌ای گزینش نشده است</h4>
                    <p className="font-sans text-xs text-stone-400 mt-1 max-w-sm">
                      برای آغاز بررسی، لطفاً یک نمونه از کلکسیون سمت چپ برگزینید یا فرتورتان را بارگذاری کنید.
                    </p>
                  </div>
                </div>
              )}

              {/* Live Loading Overlay */}
              <AnimatePresence>
                {loading && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-30 bg-[#0c1a30]/95 flex flex-col items-center justify-center p-6 text-center text-[#fefefe]"
                  >
                    <div className="relative mb-6">
                      <div className="w-20 h-20 rounded-full border-4 border-dashed border-[#c5a880] animate-spin flex items-center justify-center" />
                      <div className="absolute top-0 bottom-0 left-0 right-0 m-auto w-12 h-12 rounded-full bg-[#162a45] flex items-center justify-center text-[#c5a880]">
                        <RefreshCw className="h-6 w-6 animate-spin" />
                      </div>
                    </div>
                    
                    <motion.h4 
                      key={loadingStepIndex}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="font-sans font-bold text-base text-[#fcfaf6] max-w-lg leading-relaxed engraved-text"
                    >
                      {LOADING_STEPS[loadingStepIndex]}
                    </motion.h4>
                    
                    <p className="font-sans text-xs text-stone-400 mt-3 animate-pulse">
                      لطفاً همایون بدارید؛ این گام ممکن است چند ثانیه به درازا بکشد...
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Royal Clay Tablet Analysis Display / Visual Scroll */}
            <AnimatePresence>
              {selectedPlant ? (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="bg-white border-2 border-[#c5a880]/60 rounded-2xl overflow-hidden shadow-md relative"
                >
                  {/* Decorative header frame resembling stone lintel */}
                  <div className="h-4 bg-gradient-to-r from-[#9a7e58] via-[#e5c088] to-[#9a7e58]" />
                  
                  <div className="p-6 md:p-8 space-y-8">
                    
                    {/* Section 1: Ancient Medallions & Title Header */}
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-[#c5a880]/30">
                      <div>
                        {/* Crown/Relief tag */}
                        <div className="flex items-center gap-1.5 mb-1 bg-[#f4efe6] border border-[#c5a880]/40 px-2.5 py-0.5 rounded-full text-xs font-sans font-bold text-[#895737] w-fit">
                          <Award className="h-3.5 w-3.5 text-[#c5a880]" />
                          <span> {selectedPlant.ancientName}</span>
                        </div>
                        
                        <h2 className="font-sans font-black text-2xl md:text-3xl text-[#44382c] tracking-tight">
                          {selectedPlant.commonName}
                        </h2>
                        
                        <p className="font-sans text-sm text-stone-500 italic mt-0.5">
                          {selectedPlant.scientificName}
                        </p>
                      </div>

                      {/* Ancient Seal Rating (Confidence score) */}
                      <div className="flex items-center gap-3 bg-[#fdfaf5] border border-[#c5a880]/45 p-3 rounded-xl">
                        <div className="text-right">
                          <span className="block text-[10px] text-stone-450 font-sans">مهر تایید کاتب دربار</span>
                          <span className="font-sans font-black text-xl text-[#895737] tracking-tight">%{selectedPlant.confidence}</span>
                        </div>
                        <div className="h-10 w-10 flex items-center justify-center rounded-full bg-[#895737] text-white">
                          <CheckCircle2 className="h-6 w-6 text-[#fcfaf6]" />
                        </div>
                      </div>
                    </div>

                    {/* Section 2: Mythology Context (Zoroastrian lore or Persepolis carving) */}
                    <div className="bg-[#fcfbf9] border border-[#c5a880]/20 rounded-xl p-5 relative overflow-hidden">
                      <div className="absolute -left-12 -bottom-12 opacity-5 text-[#c5a880] select-none pointer-events-none">
                        <Scroll className="h-40 w-40" />
                      </div>
                      
                      <h4 className="font-sans font-black text-[#5c4a37] text-sm flex items-center gap-2 mb-2">
                        <BookOpen className="h-4.5 w-4.5 text-[#c5a880]" />
                        رازگشایی اساطیری و پیشینه باستانی (Amordad)
                      </h4>
                      <p className="font-sans text-sm text-[#44382c] leading-relaxed relative z-10">
                        {selectedPlant.mythology}
                      </p>
                    </div>

                    {/* Section 3: Summary diagnostic */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                      <div className="md:col-span-1 border-l-0 md:border-l border-stone-200 pl-4">
                        <h5 className="font-sans font-bold text-xs text-stone-500 uppercase tracking-widest">تحلیل اوندها</h5>
                        <p className="font-sans font-bold text-base text-[#895737] mt-1">تندرسی گیاه</p>
                      </div>
                      <div className="md:col-span-3">
                        <p className="font-sans text-sm text-stone-600 leading-relaxed">
                          {selectedPlant.summary}
                        </p>
                      </div>
                    </div>

                    {/* Section 4: The Four Pillars of Care (آب، خورشید، بستر خاک، اقلیم) */}
                    <div>
                      <h3 className="font-sans font-black text-[#5c4a37] text-base mb-5 pb-2 border-b border-[#c5a880]/15 flex items-center gap-2">
                        <Sprout className="h-5 w-5 text-[#c5a880]" />
                        چهار رکن نگهداری سلطنتی (ستون‌های پردیس)
                      </h3>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        {/* 1. Water Column */}
                        <div className="p-4 rounded-xl bg-[#fdfcf9] border border-[#c5a880]/15 flex items-start gap-3 hover:border-[#c5a880]/40 transition-colors">
                          <div className="p-2.5 rounded-lg bg-sky-50 text-sky-600">
                            <Droplets className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-sans font-bold text-sm text-[#44382c] mb-1">
                              آب‌رسانی (رکن اول - آناهیتا)
                            </h4>
                            <p className="font-sans text-xs text-stone-600 leading-relaxed">
                              {selectedPlant.careInstructions.watering}
                            </p>
                          </div>
                        </div>

                        {/* 2. Light Column */}
                        <div className="p-4 rounded-xl bg-[#fdfcf9] border border-[#c5a880]/15 flex items-start gap-3 hover:border-[#c5a880]/40 transition-colors">
                          <div className="p-2.5 rounded-lg bg-amber-50 text-amber-600">
                            <Sun className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-sans font-bold text-sm text-[#44382c] mb-1">
                              مهر تابان (رکن دوم - خورشید)
                            </h4>
                            <p className="font-sans text-xs text-stone-600 leading-relaxed">
                              {selectedPlant.careInstructions.light}
                            </p>
                          </div>
                        </div>

                        {/* 3. Soil Column */}
                        <div className="p-4 rounded-xl bg-[#fdfcf9] border border-[#c5a880]/15 flex items-start gap-3 hover:border-[#c5a880]/40 transition-colors">
                          <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
                            <Sprout className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-sans font-bold text-sm text-[#44382c] mb-1">
                              بستر اسپندارمد (رکن سوم - خاک و مایه زرین)
                            </h4>
                            <p className="font-sans text-xs text-stone-600 leading-relaxed">
                              {selectedPlant.careInstructions.soil}
                            </p>
                          </div>
                        </div>

                        {/* 4. Climate Column */}
                        <div className="p-4 rounded-xl bg-[#fdfcf9] border border-[#c5a880]/15 flex items-start gap-3 hover:border-[#c5a880]/40 transition-colors">
                          <div className="p-2.5 rounded-lg bg-indigo-50 text-indigo-600">
                            <Globe className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-sans font-bold text-sm text-[#44382c] mb-1">
                              باد و هوا (رکن چهارم - اقلیم بومی)
                            </h4>
                            <p className="font-sans text-xs text-stone-600 leading-relaxed">
                              {selectedPlant.careInstructions.climate}
                            </p>
                          </div>
                        </div>

                      </div>
                    </div>

                    {/* Section 5: Healing Traditional Medicine */}
                    <div className="border-t border-[#c5a880]/20 pt-6">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-full bg-red-55 border border-red-100 text-[#895737] mt-0.5">
                          <HeartPulse className="h-5 w-5 text-[#c5a880]" />
                        </div>
                        <div>
                          <h4 className="font-sans font-black text-sm text-[#5c4a37] mb-1">
                            عصاره شفابخش و دارویی در رساله‌های دربار
                          </h4>
                          <p className="font-sans text-xs text-stone-600 leading-relaxed">
                            {selectedPlant.healingProperties}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Section 6: Emperor's Wise Eco-Decree */}
                    <div className="pt-6 border-t-2 border-dashed border-[#c5a880]/40 text-center relative max-w-xl mx-auto">
                      <div className="inline-block p-1 bg-[#c5a880]/10 border border-[#c5a880]/40 rounded-full mb-2">
                        <Scroll className="h-4 w-4 text-[#895737]" />
                      </div>
                      <h4 className="font-serif font-black text-[#5c4a37] text-sm italic mb-1.5">
                        فرمان شاهانه پاسداری از زمینِ پارس
                      </h4>
                      <p className="font-sans text-sm text-[#895737] leading-relaxed font-semibold italic">
                        {selectedPlant.royalAdvice}
                      </p>
                    </div>

                  </div>
                </motion.div>
              ) : (
                !loading && (
                  <div className="bg-white border border-stone-200 rounded-xl p-8 text-center text-stone-500">
                    <p className="font-sans">تصویری تحلیل نیافته است. لطفاً نمونه‌ای بیاموزید یا بارگذاری فرمایید.</p>
                  </div>
                )
              )}
            </AnimatePresence>

          </div>

        </div>
      </main>

      {/* Built-in Camera Modality Portal */}
      <AnimatePresence>
        {showCamera && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-2xl overflow-hidden max-w-lg w-full border border-[#c5a880] shadow-2xl"
            >
              <div className="p-4 bg-[#f8f5ee] border-b border-[#c5a880]/20 flex justify-between items-center">
                <h3 className="font-sans font-bold text-[#5c4a37] flex items-center gap-2">
                  <Camera className="h-5 w-5 text-[#c5a880]" />
                  دوربین دیوان شاهنشاهی مجهز به چشم باغبان
                </h3>
                <button 
                  onClick={closeCamera}
                  className="p-1 rounded-full text-stone-400 hover:text-stone-700 cursor-pointer"
                >
                  <VideoOff className="h-5 w-5" />
                </button>
              </div>

              {/* Real Video Capture Feed */}
              <div className="relative bg-black h-80 flex items-center justify-center">
                <video 
                  ref={videoRef}
                  autoPlay 
                  playsInline 
                  className="w-full h-full object-cover scale-x-[-1]"
                />
                
                {/* Visual Camera target guide */}
                <div className="absolute inset-0 m-auto w-56 h-56 border-2 border-dashed border-[#c5a880]/75 rounded-2xl pointer-events-none" />
              </div>

              {/* Camera Actions */}
              <div className="p-4 space-y-3 bg-[#fdfbfc] flex flex-col items-center">
                <p className="font-sans text-[11px] text-stone-500 text-center">
                  برگ یا کلیت گیاه را به گونه‌ای مقابل دایره دوربین بنشانید که کاملاً در فوکوس خورشید تابان قرار گیرد.
                </p>
                <div className="flex gap-3 w-full">
                  <button
                    id="capture-plant-photo"
                    onClick={capturePhoto}
                    className="flex-1 py-2.5 rounded-lg bg-[#c5a880] hover:bg-[#b0936b] text-white font-sans font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <CheckCircle2 className="h-5 w-5" />
                    ثبت نبشته و تحلیل گیاه
                  </button>
                  <button
                    id="close-camera-modal"
                    onClick={closeCamera}
                    className="px-5 py-2.5 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-700 font-sans font-bold text-sm transition-all cursor-pointer"
                  >
                    انصراف
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Ancient Footer */}
      <footer className="mt-16 text-center select-none space-y-2">
        <p className="font-sans text-xs text-stone-450 leading-relaxed font-normal">
          پردیس شاهنشاهی پارس • طراحی شده با الهام و خرد معماری جاودان هخامنشی به مهر و صلح
        </p>
        <p className="font-sans text-[10px] text-stone-400 uppercase tracking-wider">
          Achaemenid Botanical Portal | Powered by Gemini 3.5 Flash
        </p>
      </footer>

    </div>
  );
}
